#!/system/bin/sh

if [ -f /data/local/bootanimation.zip ]; then
  /sbin/bootanimation
elif [ -f /system/media/bootanimation.zip ]; then
  /sbin/bootanimation
else
  /system/bin/samsungani
fi
