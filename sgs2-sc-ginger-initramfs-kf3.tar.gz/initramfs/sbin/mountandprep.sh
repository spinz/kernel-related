#!/bin/sh

#/dev/block/mmcblk0p10 /data ext4 rw,nosuid,nodev,noatime,barrier=1,data=ordered,noauto_da_alloc,discard 0 0
