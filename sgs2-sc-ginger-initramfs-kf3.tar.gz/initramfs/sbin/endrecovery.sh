#!/bin/sh
mkdir /sdcard/supercore
cp /tmp/recovery.log /sdcard/supercore/recovery.log
